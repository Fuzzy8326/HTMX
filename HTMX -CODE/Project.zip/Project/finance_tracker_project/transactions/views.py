from django.shortcuts import render, get_object_or_404, redirect
from django.db.models import Sum, Q
from .models import Transaction
from django.views.decorators.csrf import csrf_protect
from django.http import HttpResponse, HttpResponseForbidden

# ----------------------------
# Dashboard / Home page view
# ----------------------------
def index(request):
    transactions = Transaction.objects.all()
    
    # Calculate total income
    income = transactions.filter(transaction_type='income').aggregate(
        total=Sum('amount'))['total'] or 0

    # Calculate total expenses
    expense = transactions.filter(transaction_type='expense').aggregate(
        total=Sum('amount'))['total'] or 0

    # Calculate balance
    balance = income - expense
    
    context = {
        'transactions': transactions,
        'income': income,
        'expense': expense,
        'balance': balance,
    }
    return render(request, 'index.html', context)

# ----------------------------
# Transaction list (HTMX dynamic updates)
# ----------------------------
def transaction_list(request):
    search = request.GET.get('search', '')
    filter_type = request.GET.get('type', '')
    
    transactions = Transaction.objects.all()
    
    # Filter by search term (title or description)
    if search:
        transactions = transactions.filter(
            Q(title__icontains=search) | 
            Q(description__icontains=search)
        )
    
    # Filter by transaction type (income/expense)
    if filter_type:
        transactions = transactions.filter(transaction_type=filter_type)
    
    # Return partial HTML for HTMX updates
    return render(request, 'partials/transaction_list.html', 
                  {'transactions': transactions})

# ----------------------------
# Create new transaction (HTMX modal)
# ----------------------------
def create_transaction(request):
    if request.method == 'POST':
        Transaction.objects.create(
            title=request.POST['title'],
            amount=request.POST['amount'],
            transaction_type=request.POST['transaction_type'],
            category=request.POST['category'],
            description=request.POST.get('description', ''),
            date=request.POST['date']
        )
        return redirect('index')  # HTMX will follow the redirect
    # Render the modal form
    return render(request, 'partials/transaction_form.html')

# ----------------------------
# Edit transaction (HTMX modal)
# ----------------------------
def edit_transaction(request, pk):
    transaction = get_object_or_404(Transaction, pk=pk)
    
    if request.method == 'POST':
        transaction.title = request.POST['title']
        transaction.amount = request.POST['amount']
        transaction.transaction_type = request.POST['transaction_type']
        transaction.category = request.POST['category']
        transaction.description = request.POST.get('description', '')
        transaction.date = request.POST['date']
        transaction.save()
        return redirect('index')  # HTMX follows redirect
    
    # Render modal with current transaction data
    return render(request, 'partials/transaction_edit.html', 
                  {'transaction': transaction})

# ----------------------------
# Delete transaction (HTMX request)
# ----------------------------
@csrf_protect
def delete_transaction(request, pk):
    if request.method == "DELETE":
        transaction = Transaction.objects.filter(pk=pk)
        if transaction.exists():
            transaction.delete()
            return HttpResponse("")  # 200 OK for HTMX to remove card
        return HttpResponseForbidden("Transaction not found")
    return HttpResponseForbidden("Invalid method")

# ----------------------------
# Summary data (total income, expenses, balance)
# ----------------------------
def summary(request):
    transactions = Transaction.objects.all()
    
    income = transactions.filter(transaction_type='income').aggregate(
        total=Sum('amount'))['total'] or 0

    expense = transactions.filter(transaction_type='expense').aggregate(
        total=Sum('amount'))['total'] or 0

    balance = income - expense
    
    context = {
        'income': income,
        'expense': expense,
        'balance': balance,
    }
    # Return partial HTML for HTMX summary update
    return render(request, 'partials/summary.html', context)

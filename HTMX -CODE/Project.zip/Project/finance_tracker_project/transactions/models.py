from django.db import models
from django.core.validators import MinValueValidator
from decimal import Decimal

class Transaction(models.Model):
    # Choices for transaction type (income or expense)
    TRANSACTION_TYPES = [
        ('income', 'Income'),
        ('expense', 'Expense'),
    ]
    
    # Categories for transactions
    CATEGORIES = [
        ('salary', 'Salary'),
        ('freelance', 'Freelance'),
        ('investment', 'Investment'),
        ('food', 'Food'),
        ('transport', 'Transport'),
        ('entertainment', 'Entertainment'),
        ('utilities', 'Utilities'),
        ('healthcare', 'Healthcare'),
        ('other', 'Other'),
    ]
    
    # Transaction title
    title = models.CharField(max_length=200)
    
    # Amount of the transaction
    amount = models.DecimalField(
        max_digits=10,             # Maximum number of digits (including decimal places)
        decimal_places=2,          # Two decimal places for cents
        validators=[MinValueValidator(Decimal('0.01'))]  # Amount must be at least 0.01
    )
    
    # Type of transaction: income or expense
    transaction_type = models.CharField(max_length=10, choices=TRANSACTION_TYPES)
    
    # Category of transaction
    category = models.CharField(max_length=50, choices=CATEGORIES)
    
    # Optional description
    description = models.TextField(blank=True)
    
    # Date of transaction
    date = models.DateField()
    
    # Automatically set when created
    created_at = models.DateTimeField(auto_now_add=True)
    
    # Automatically updated on save
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        # Default ordering: newest transactions first
        ordering = ['-date', '-created_at']
    
    def __str__(self):
        # Human-readable representation of the transaction
        return f"{self.title} - ${self.amount}"

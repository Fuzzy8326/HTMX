from django.urls import path
from . import views

urlpatterns = [
    # Home page / dashboard
    path('', views.index, name='index'),

    # List all transactions (used for HTMX dynamic updates)
    path('transactions/', views.transaction_list, name='transaction_list'),

    # Create a new transaction (HTMX modal form)
    path('transactions/create/', views.create_transaction, name='create_transaction'),

    # Edit an existing transaction by primary key (HTMX modal form)
    path('transactions/<int:pk>/edit/', views.edit_transaction, name='edit_transaction'),

    # Delete a transaction by primary key (HTMX request)
    path('transactions/<int:pk>/delete/', views.delete_transaction, name='delete_transaction'),

    # Return the summary data (total income, expenses, balance)
    path('summary/', views.summary, name='summary'),
]
